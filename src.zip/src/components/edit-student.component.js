// EditStudent Component for update student data

// Import Modules
import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link, useParams,useNavigate } from 'react-router-dom';
import StudentForm from "./StudentForm";


// EditStudent Component



const EditStudent = (props) => {
const [formValues, setFormValues] = useState({
	name: "",
	email: "",
	phone: "",
     
});





const { id } = useParams();
const navigate = useNavigate();
//onSubmit handler
const onSubmit = (studentObject) => {
	// axios
	// .put(
	// 	 "https://codes.biglittleideas.com/learnreact/updatestudent.php?stdid="+id,
	// 	studentObject
	// )
    
    Object.assign(studentObject, { ['stdid']:id });
    axios.post( 
        'https://codes.biglittleideas.com/learnreact/updatestudent.php',
      studentObject)
	.then((res) => {
		// if (res.status === 200) {
		alert("Student successfully updated");
        navigate("/student-list");
        
        //props.history.push("/student-list");
		

        //} else Promise.reject();
	})
	//.catch((err) => alert("Something went wrong"));
};
console.log(id);
// Load data from server and reinitialize student form
useEffect(() => {
	axios
	.get(
        "https://codes.biglittleideas.com/learnreact/studentjson.php?stdid="+id
	)
	.then((res) => {
		const  name = res.data[0].newuser_name;
        const  email = res.data[0].newuser_email;
        const  phone = res.data[0].newuser_phone;
        
       console.log(res.data[0].newuser_name);
        setFormValues({ name,email,phone });
	})
	.catch((err) => console.log(err));
}, []);

// Return student form
return (
	<StudentForm
	initialValues={formValues}
	onSubmit={onSubmit}
	enableReinitialize
	>
	Update Student
	</StudentForm>
);
};

// Export EditStudent Component
export default EditStudent;