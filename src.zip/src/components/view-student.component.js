// EditStudent Component for update student data

// Import Modules
import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link, useParams,useNavigate , useSearchParams } from 'react-router-dom';

// ViewStudent Component

const ViewStudent = (props) => {

const [formFieldValues,setFieldValues] = useState({
	name: "",
	email: "",
	phone: "",
});

const { id } = useParams();
const navigate = useNavigate();

//const queryParameters = new URLSearchParams(window.location.search)  // USED IN ROUTER VERSION 5
const [queryParameters] = useSearchParams() ;   // USED IN ROUTER DOM Version 6
const type = queryParameters.get("id")
console.log(type);

//console.log(id);
// Load data from server and reinitialize student form
useEffect(() => {
	axios
	.get(
        "https://codes.biglittleideas.com/learnreact/studentjson.php?stdid="+id
	)
	.then((res) => {
		const  name1 = res.data[0].newuser_name;
        const  email2 = res.data[0].newuser_email;
        const  phone = res.data[0].newuser_phone;
        
         console.log(res.data[0].newuser_name);
        setFieldValues({ name1,email2,phone });
	})
	.catch((err) => console.log(err));
}, []);

// Return student form
 
return (
   <>
	<h3>Showing Student</h3>
     <ul> 
        <li>Student Name : {formFieldValues.name1} </li>
        <li>Student Email : {formFieldValues.email2} </li>
        <li>Student Phone : {formFieldValues.phone} </li>

     </ul>
  </>
);
};

// Export EditStudent Component
export default ViewStudent;