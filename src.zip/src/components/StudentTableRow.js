import React from "react";
import { Button } from "react-bootstrap";
import { Link } from "react-router-dom";
import axios from "axios";

const StudentTableRow = (props) => {
const { newuser_id, newuser_name, newuser_phone, newuser_email} = props.obj;

// const deleteStudent = () => {
// 	axios
// 	.delete(
// "http://localhost:4000/students/delete-student/" + _id)
// 	.then((res) => {
// 		if (res.status === 200) {
// 		alert("Student successfully deleted");
// 		window.location.reload();
// 		} else Promise.reject();
// 	})
// 	.catch((err) => alert("Something went wrong"));
// };

return (
	<tr>
	  <td>{newuser_name}</td>
	  <td>{newuser_phone}</td>
	  <td>{newuser_email}</td>  
	  <td>
		<Link className="edit-link"
		to={"/edit-student/" + newuser_id}>
		Edit
		</Link>
      
		<Link className="edit-link"
		to={"/view-student/" + newuser_id}>
		View Info
		</Link>


		{/* <Button onClick={deleteStudent}
		size="sm" variant="danger">
		Delete
		</Button> */}
	 </td>
	</tr>
);
};

export default StudentTableRow;