import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes,Route, Link } from "react-router-dom";
import axios from "axios";
import { Table } from "react-bootstrap";
import StudentTableRow from "./StudentTableRow";
import CreateStudent from
	"./create-student.component";

const StudentList = () => {
const [students, setStudents] = useState([]);

const [searchInput, setSearchInput] = useState('');
const [searchGenInput, setSearchGenInput] = useState('');
const [searchText, setSearchInputText] = useState('');


const searchItems = (searchValue) => {
	setSearchInput(searchValue)
	//console.log(searchValue); 
}

const searchGender = (searchVal) => {
	setSearchGenInput(searchVal)
	//console.log(searchVal); 
}

const searchTextItem = (searchInText) => {
	setSearchInputText(searchInText)
	//console.log(searchInText); 
}
  
// const handleChange = (evt) => 
// { 
//   setSearchInputText(evt.target.name)
// };



useEffect(() => {

	axios
    .get("https://codes.biglittleideas.com/learnreact/studentjson.php?searchcity="+searchInput+"&searchgender="+searchGenInput+"&searchtext="+searchText )
	.then(({ data }) => {
		setStudents(data);
	})
	.catch((error) => {
		console.log(error);
	});
}, [searchInput,searchGenInput,searchText]);



const DataTable = () => {
	return students.map((res, i) => {
	return <StudentTableRow obj={res} key={i} />;
	});
};

return (
	<div className="table-wrapper">
  
       
    <Link className="add-link"   
		to={"/create-student"} style={{margin: "5%"}} >
		Add New Student
	</Link>
 
 <div className="Row">
   
    <input type="text" className="form-control"   placeholder="Search By name" onMouseOut={(e) => searchTextItem(e.target.value)}   /> 

   

   <select name="city" className="form-control" onChange={(e) => searchItems(e.target.value)} style={{marginTop:"5%" }}>
	  <option value="">Search By City</option> 
		<option value="1">Chandigarh</option>
		<option value="2">Banglore</option>
		<option value="3">Udaipur</option>
		<option value="4">Bhopal</option>
    </select>
   
   <select name="gender" className="form-control" onChange={(e) => searchGender(e.target.value)} style={{marginTop:"5%" }}>
	  <option value="">Search By Gender</option> 
		<option value="1">Male</option>
		<option value="2">Female</option>
    </select>
   


</div>


<div className="Row" style={{marginTop:"5%"}} >
    <Table striped bordered hover>
		<thead>
		<tr>
			<th>Name</th>
			<th>Phone</th>
			<th>Email</th>
			<th>Action</th>
		</tr>
		</thead>
		<tbody>{DataTable()}</tbody>
	</Table>
	</div>
 </div>	
);
};

export default StudentList;